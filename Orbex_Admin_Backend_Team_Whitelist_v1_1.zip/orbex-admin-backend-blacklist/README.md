# Orbex – Administration + Backend + Blacklist (Update v1.1)

Dieses Paket baut auf dem bisherigen statischen Orbex-Dashboard auf und ergänzt:
- Administration mit fest konfigurierter Owner-ID
- Admin-Freigaben (nur Owner darf Admins hinzufügen/entfernen)
- Blacklist-Verwaltung (Owner und freigegebene Admins)
- FastAPI-Backend mit SQLite-Datenbank
- Discord OAuth2 Login (`identify`)
- Serverseitige Berechtigungsprüfung für geschützte API-Routen
- Team-Whitelist mit dauerhafter SQLite-Speicherung (Rollen: Teammitglied, Moderator, Admin-Team)
- Blacklist-Sperre: gesperrte Discord-Konten werden bei geschützten API-Anfragen abgewiesen

## Owner
Die Owner-ID ist bereits voreingestellt:
`1479800737377816656`

Sie steht als `OWNER_DISCORD_ID` in `.env.example`. Die Owner-ID ist im Dashboard schreibgeschützt und wird vom Backend aus der Server-Konfiguration gelesen. Nicht in JavaScript ändern.

## Lokal starten
1. Python 3.11 oder neuer installieren.
2. ZIP entpacken.
3. Im Projektordner `.env.example` zu `.env` kopieren.
4. In `.env` Discord Client ID und Client Secret eintragen.
5. `SESSION_SECRET` durch einen langen zufälligen geheimen Wert ersetzen.
6. Im Discord Developer Portal bei OAuth2 Redirects exakt diese URL eintragen:
   `http://127.0.0.1:8000/auth/callback`
7. Terminal im Projektordner öffnen und ausführen:
   `pip install -r requirements.txt`
   `uvicorn main:app --host 127.0.0.1 --port 8000`
8. Browser öffnen: `http://127.0.0.1:8000`

## Wichtig
- Discord Login funktioniert erst nach Eintragen der OAuth-App-Daten.
- `DISCORD_BOT_TOKEN` gehört ausschließlich in `.env` auf dem Backend-Server, niemals in HTML/JavaScript oder GitHub.
- Diese Version speichert Admins, Blacklist und Dashboard-Einstellungen in SQLite.
- Bei einem Hosting-Anbieter muss ein persistenter Speicher für `DATABASE_PATH` eingerichtet werden, sonst kann eine SQLite-Datei bei einem Neustart/Deploy verloren gehen.
- Für eine getrennte Vercel-Frontend-/Backend-Domain sind zusätzliche CORS- und Cookie-Einstellungen nötig. Dieses Paket startet zunächst als eine gemeinsame App.
- Blacklist-Einträge werden hier in Orbex gespeichert. Das automatische Blockieren eines Discord-Benutzers auf Discord-Servern wird erst mit der späteren Bot-/Guild-Integration umgesetzt.
- Noch keine Discord-Bot-Aktionen und keine Rollen-/Kanalabfrage; dafür wird die Bot-Verbindung als nächster Schritt ergänzt.
- Vor dem Live-Einsatz auf HTTPS umstellen und `COOKIE_HTTPS_ONLY=true` setzen.


## Team-Whitelist Update v1.1
- Im Dashboard gibt es jetzt den Bereich „Team-Whitelist“.
- Owner und freigegebene Admins können Discord-IDs hinzufügen, Rollen setzen und Einträge entfernen.
- Die Einträge werden in der SQLite-Tabelle `team_whitelist` gespeichert.
- Die Whitelist ist aktuell eine separate Team-Liste. Sie ersetzt nicht die Admin-Freigabe in `admins` und gewährt für sich allein keine Admin-Rechte.
- Die Blacklist wird nun bei authentifizierten API-Aufrufen geprüft; gesperrte Konten werden abgewiesen und ihre Dashboard-Session wird geleert.
- Für dauerhafte Daten muss Render einen persistenten Datenträger für `DATABASE_PATH` verwenden.
