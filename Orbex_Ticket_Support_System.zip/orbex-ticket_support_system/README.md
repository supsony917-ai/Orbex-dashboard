# Orbex Ticket_Support_System
Enthält eine eigenständige HTML-Oberfläche, CSS, JavaScript, Beispielkonfiguration und Backend-Starter.
Für echte Discord-Kanal-/Rollenlisten muss das Backend `GET /api/discord/options` bereitstellen: `channels`, `voiceChannels`, `categories`, `roles` (jeweils Objekte mit `id` und `name`). Sichere OAuth- und Serverberechtigungsprüfung ist erforderlich. Ohne Backend speichert die Vorlage lokal und exportiert JSON; sie führt noch keine echten Bot-Aktionen aus. Bot-Token niemals im Browser speichern.
