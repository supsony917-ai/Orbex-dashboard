ORBEX – TEAM-WHITELIST UPDATE

Enthalten:
- index.html: Dashboard-Oberfläche mit neuer Team-Whitelist-Seite.
- Der Discord-Login-Link bleibt enthalten.
- Die bisherige Optik und die vorhandenen Dashboard-Seiten bleiben erhalten.

WICHTIG:
Dies ist zunächst die Frontend-/Vorschau-Stufe. Einträge werden nur im Arbeitsspeicher der geöffneten Seite gehalten. Sie werden NICHT dauerhaft gespeichert und ändern noch KEINE echten Zugriffsrechte.
Für echte Team-Whitelist-Funktionen muss das Orbex-Backend eine geschützte API bereitstellen (nur angemeldete, berechtigte Administratoren dürfen Einträge lesen/ändern). Diese ZIP behauptet ausdrücklich nicht, dass diese Backend-Verbindung bereits besteht.

Einbau:
1. Im Vercel-Projekt die bisherige index.html durch diese index.html ersetzen.
2. orbex-logo.jpg im selben Ordner beibehalten.
3. Danach neu deployen.

Die bestehende Backend-ZIP und andere Modul-ZIPs werden nicht ersetzt.
