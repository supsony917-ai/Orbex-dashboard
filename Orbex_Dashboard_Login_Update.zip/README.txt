ORBEX DASHBOARD – LOGIN UPDATE

Enthalten:
- index.html: bestehendes Dashboard mit zusätzlichem „Mit Discord anmelden“-Button.
- Der Button startet den OAuth-Login am vorhandenen Render-Backend:
  https://orbex-dashboard-4.onrender.com/auth/login

WICHTIG:
- Diese ZIP ist ein zusätzliches Update-Paket. Die bisherigen ZIP-Dateien und Dateien im GitHub-Repository bleiben unverändert.
- Die ZIP enthält absichtlich keine Discord-Client-Secrets oder sonstige Zugangsdaten.
- Der Button startet den Login-Ablauf. Damit die Anmeldung danach auch eine Sitzung im Vercel-Dashboard öffnet und die Panels Daten laden, muss die Frontend-/Backend-Sitzungsübergabe noch separat geprüft und eingerichtet werden.
- Das Logo orbex-logo.jpg wird weiterhin aus dem bestehenden Vercel-Projektordner geladen. Beim Einspielen daher die vorhandene Logo-Datei nicht löschen.
