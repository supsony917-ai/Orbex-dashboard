# FastAPI-Starter (mit Orbex-Backend verbinden)
from fastapi import APIRouter
router=APIRouter()
@router.get("/api/discord/options")
async def options():
    # TODO: Discord-Guild sicher abrufen
    return {"channels":[],"voiceChannels":[],"categories":[],"roles":[]}
