ORBEX DASHBOARD – Welcome + Administration (Vorschau)

Enthalten:
- index.html
- orbex-logo.jpg

WICHTIG:
Die Administration/Blacklist ist in diesem Paket nur eine Frontend-Demo.
Es gibt noch keine sichere Hersteller-Anmeldung, serverseitige Rechteprüfung,
Datenbank oder Verbindung zum BDFD-Bot. Nicht als echte Moderations- oder
Blacklist-Verwaltung öffentlich einsetzen, bevor diese Backend-Funktionen
implementiert wurden.

GitHub:
1. Im Repository orbex-dashboard die alte index.html öffnen.
2. Datei löschen/ersetzen und diese neue index.html hochladen.
3. orbex-logo.jpg ebenfalls hochladen bzw. ersetzen.
4. Commit changes drücken.
5. Vercel sollte anschließend automatisch neu deployen.
