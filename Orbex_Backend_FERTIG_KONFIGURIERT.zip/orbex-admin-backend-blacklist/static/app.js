const $ = id => document.getElementById(id);
let me = null;
async function api(path, options={}) {
  const res = await fetch(path, {credentials:"same-origin", headers:{"Content-Type":"application/json", ...(options.headers||{})}, ...options});
  const data = await res.json().catch(()=>({}));
  if (!res.ok) throw new Error(data.detail || "Anfrage fehlgeschlagen");
  return data;
}
function note(msg, bad=false){$("notice").textContent=msg;$("notice").style.color=bad?"#ff9ca8":"#9fe4b7";}
function page(id){
  document.querySelectorAll(".page").forEach(x=>x.classList.toggle("active",x.id===id));
  document.querySelectorAll(".nav").forEach(x=>x.classList.toggle("active",x.dataset.page===id));
  $("title").textContent={home:"Übersicht",administration:"Administration",blacklist:"Blacklist"}[id];
}
document.querySelectorAll(".nav").forEach(b=>b.addEventListener("click",()=>page(b.dataset.page)));
$("login").onclick=()=>location.href="/auth/login";
$("logout").onclick=async()=>{try{await api("/auth/logout",{method:"POST"});location.reload()}catch(e){note(e.message,true)}};
async function refresh(){
  try{
    const health=await api("/api/health"); $("backendState").textContent=health.ok?"Verbunden":"Nicht erreichbar";
    me=await api("/api/me"); $("ownerHome").textContent=me.owner_id; $("ownerId").value=me.owner_id;
    if(me.logged_in){
      $("identity").textContent=me.user.username+" · "+me.user.id;
      $("login").classList.add("hidden");$("logout").classList.remove("hidden");
      $("accessText").textContent=me.is_owner?"Du bist als Owner angemeldet.":me.is_admin?"Du bist als Admin freigegeben.":"Du bist angemeldet, hast aber keine Admin-Rechte.";
      if(me.is_admin){await loadAdmins();await loadSettings();await loadBlacklist();}
    } else {$("accessText").textContent="Bitte mit Discord anmelden.";}
  }catch(e){$("backendState").textContent="Fehler";note(e.message,true)}
}
async function loadAdmins(){
  const d=await api("/api/admin/admins"); $("adminList").innerHTML="<h3>Freigegebene Admins</h3>";
  if(!d.admins.length)$("adminList").innerHTML+="<p class='muted'>Noch keine zusätzlichen Admins.</p>";
  for(const a of d.admins){const row=document.createElement("div");row.className="entry";const span=document.createElement("span");span.textContent=a.user_id;const btn=document.createElement("button");btn.className="danger";btn.textContent="Entfernen";btn.disabled=!me.is_owner;btn.onclick=async()=>{try{await api("/api/admin/admins/"+a.user_id,{method:"DELETE"});await loadAdmins();note("Admin entfernt.")}catch(e){note(e.message,true)}};row.append(span,btn);$("adminList").append(row);}
  $("addAdmin").disabled=!me.is_owner;
}
async function loadSettings(){
  const d=await api("/api/admin/settings");$("adminRole").value=d.settings.admin_role_id||"";$("logChannel").value=d.settings.log_channel_id||"";
}
$("addAdmin").onclick=async()=>{try{await api("/api/admin/admins",{method:"POST",body:JSON.stringify({user_id:$("newAdmin").value.trim()})});$("newAdmin").value="";await loadAdmins();note("Admin freigegeben.")}catch(e){note(e.message,true)}};
$("saveSettings").onclick=async()=>{try{await api("/api/admin/settings",{method:"PUT",body:JSON.stringify({settings:{admin_role_id:$("adminRole").value.trim(),log_channel_id:$("logChannel").value.trim()}})});note("Einstellungen gespeichert.")}catch(e){note(e.message,true)}};
async function loadBlacklist(){
  const d=await api("/api/blacklist");$("blackList").innerHTML="<h3>Gesperrte Nutzer ("+d.entries.length+")</h3>";
  if(!d.entries.length)$("blackList").innerHTML+="<p class='muted'>Die Blacklist ist leer.</p>";
  for(const x of d.entries){const row=document.createElement("div");row.className="entry";const info=document.createElement("span");info.textContent=x.user_id+" — "+x.reason;const btn=document.createElement("button");btn.className="danger";btn.textContent="Entfernen";btn.onclick=async()=>{try{await api("/api/blacklist/"+x.user_id,{method:"DELETE"});await loadBlacklist();note("Eintrag entfernt.")}catch(e){note(e.message,true)}};row.append(info,btn);$("blackList").append(row);}
}
$("addBlack").onclick=async()=>{try{await api("/api/blacklist",{method:"POST",body:JSON.stringify({user_id:$("blackUser").value.trim(),reason:$("blackReason").value.trim()})});$("blackUser").value="";$("blackReason").value="";await loadBlacklist();note("Nutzer zur Blacklist hinzugefügt.")}catch(e){note(e.message,true)}};
refresh();
