import os, re, json, secrets, sqlite3
from pathlib import Path
from contextlib import contextmanager
from urllib.parse import urlencode

import httpx
from dotenv import load_dotenv
from fastapi import FastAPI, Request, HTTPException
from fastapi.responses import RedirectResponse, JSONResponse, FileResponse
from fastapi.staticfiles import StaticFiles
from starlette.middleware.sessions import SessionMiddleware

# Render Secret Files werden unter /etc/secrets bereitgestellt.
# Lokal wird weiterhin die .env-Datei im Projektordner geladen.
render_env = Path("/etc/secrets/.env")
local_env = Path(__file__).resolve().parent / ".env"
if render_env.exists():
    load_dotenv(render_env, override=True)
else:
    load_dotenv(local_env, override=True)

APP_DIR = Path(__file__).resolve().parent
DB_PATH = os.getenv("DATABASE_PATH", str(APP_DIR / "orbex.db"))
OWNER_ID = os.getenv("OWNER_DISCORD_ID", "1479800737377816656").strip()
CLIENT_ID = os.getenv("DISCORD_CLIENT_ID", "").strip()
CLIENT_SECRET = os.getenv("DISCORD_CLIENT_SECRET", "").strip()
REDIRECT_URI = os.getenv("DISCORD_REDIRECT_URI", "http://127.0.0.1:8000/auth/callback").strip()
SESSION_SECRET = os.getenv("SESSION_SECRET", "CHANGE_THIS_TO_A_LONG_RANDOM_SECRET")
BOT_TOKEN = os.getenv("DISCORD_BOT_TOKEN", "").strip()  # Server-only; never send to the browser.

if not re.fullmatch(r"\d{17,20}", OWNER_ID):
    raise RuntimeError("OWNER_DISCORD_ID muss eine gültige Discord-ID sein.")
if SESSION_SECRET == "CHANGE_THIS_TO_A_LONG_RANDOM_SECRET":
    print("WARNUNG: Bitte SESSION_SECRET in .env durch einen langen Zufallswert ersetzen.")

app = FastAPI(title="Orbex Backend", version="1.0.0")
app.add_middleware(
    SessionMiddleware,
    secret_key=SESSION_SECRET,
    same_site="lax",
    https_only=os.getenv("COOKIE_HTTPS_ONLY", "false").lower() == "true",
    max_age=60 * 60 * 24 * 7,
)

@contextmanager
def db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    try:
        yield conn
        conn.commit()
    finally:
        conn.close()

def init_db():
    Path(DB_PATH).parent.mkdir(parents=True, exist_ok=True)
    with db() as c:
        c.execute("""CREATE TABLE IF NOT EXISTS admins (
            user_id TEXT PRIMARY KEY, added_at TEXT DEFAULT CURRENT_TIMESTAMP
        )""")
        c.execute("""CREATE TABLE IF NOT EXISTS blacklist (
            user_id TEXT PRIMARY KEY, reason TEXT NOT NULL,
            added_by TEXT NOT NULL, added_at TEXT DEFAULT CURRENT_TIMESTAMP
        )""")
        c.execute("""CREATE TABLE IF NOT EXISTS settings (
            key TEXT PRIMARY KEY, value TEXT NOT NULL
        )""")
        c.execute("INSERT OR IGNORE INTO settings(key,value) VALUES('dashboard', '{}')")

init_db()

def valid_discord_id(value):
    return isinstance(value, str) and re.fullmatch(r"\d{17,20}", value) is not None

def current_user(request: Request):
    user = request.session.get("user")
    if not user or not valid_discord_id(str(user.get("id", ""))):
        raise HTTPException(status_code=401, detail="Bitte zuerst mit Discord anmelden.")
    return user

def is_owner(user):
    return str(user["id"]) == OWNER_ID

def is_admin(user):
    if is_owner(user):
        return True
    with db() as c:
        return c.execute("SELECT 1 FROM admins WHERE user_id=?", (str(user["id"]),)).fetchone() is not None

def require_admin(request: Request):
    user = current_user(request)
    if not is_admin(user):
        raise HTTPException(status_code=403, detail="Keine Berechtigung.")
    return user

def require_owner(request: Request):
    user = current_user(request)
    if not is_owner(user):
        raise HTTPException(status_code=403, detail="Nur der Orbex-Owner darf das.")
    return user

@app.get("/api/health")
def health():
    return {"ok": True, "service": "orbex-backend", "version": "1.0.0"}

@app.get("/auth/login")
def login(request: Request):
    if not CLIENT_ID or not CLIENT_SECRET:
        raise HTTPException(status_code=503, detail="Discord OAuth ist noch nicht eingerichtet. Bitte .env ausfüllen.")
    state = secrets.token_urlsafe(32)
    request.session["oauth_state"] = state
    params = {
        "client_id": CLIENT_ID,
        "redirect_uri": REDIRECT_URI,
        "response_type": "code",
        "scope": "identify",
        "state": state,
        "prompt": "consent",
    }
    return RedirectResponse("https://discord.com/oauth2/authorize?" + urlencode(params))

@app.get("/auth/callback")
async def callback(request: Request, code: str = "", state: str = ""):
    expected = request.session.pop("oauth_state", None)
    if not expected or not secrets.compare_digest(expected, state):
        raise HTTPException(status_code=400, detail="OAuth-State ungültig. Bitte erneut anmelden.")
    if not code or not CLIENT_ID or not CLIENT_SECRET:
        raise HTTPException(status_code=400, detail="Discord-Anmeldung fehlgeschlagen.")
    async with httpx.AsyncClient(timeout=15) as client:
        token_response = await client.post(
            "https://discord.com/api/oauth2/token",
            data={
                "client_id": CLIENT_ID,
                "client_secret": CLIENT_SECRET,
                "grant_type": "authorization_code",
                "code": code,
                "redirect_uri": REDIRECT_URI,
            },
            headers={"Content-Type": "application/x-www-form-urlencoded"},
        )
        if token_response.status_code != 200:
            raise HTTPException(status_code=400, detail="Discord hat den Login nicht bestätigt.")
        access_token = token_response.json().get("access_token")
        user_response = await client.get(
            "https://discord.com/api/users/@me",
            headers={"Authorization": f"Bearer {access_token}"},
        )
        if user_response.status_code != 200:
            raise HTTPException(status_code=400, detail="Discord-Profil konnte nicht geladen werden.")
        discord_user = user_response.json()
    request.session["user"] = {
        "id": str(discord_user["id"]),
        "username": discord_user.get("global_name") or discord_user.get("username", "Discord User"),
        "avatar": discord_user.get("avatar"),
    }
    return RedirectResponse("/", status_code=303)

@app.post("/auth/logout")
def logout(request: Request):
    request.session.clear()
    return {"ok": True}

@app.get("/api/me")
def me(request: Request):
    user = request.session.get("user")
    if not user:
        return {"logged_in": False, "owner_id": OWNER_ID}
    return {
        "logged_in": True,
        "user": user,
        "is_owner": is_owner(user),
        "is_admin": is_admin(user),
        "owner_id": OWNER_ID,
    }

@app.get("/api/admin/admins")
def list_admins(request: Request):
    require_admin(request)
    with db() as c:
        rows = c.execute("SELECT user_id, added_at FROM admins ORDER BY added_at").fetchall()
    return {"admins": [dict(r) for r in rows], "owner_id": OWNER_ID}

@app.post("/api/admin/admins")
async def add_admin(request: Request):
    owner = require_owner(request)
    data = await request.json()
    user_id = str(data.get("user_id", "")).strip()
    if not valid_discord_id(user_id):
        raise HTTPException(status_code=422, detail="Bitte eine gültige Discord-Benutzer-ID eingeben.")
    if user_id == OWNER_ID:
        raise HTTPException(status_code=409, detail="Der Owner ist bereits automatisch Admin.")
    with db() as c:
        c.execute("INSERT OR IGNORE INTO admins(user_id) VALUES(?)", (user_id,))
    return {"ok": True, "user_id": user_id}

@app.delete("/api/admin/admins/{user_id}")
def remove_admin(user_id: str, request: Request):
    require_owner(request)
    if not valid_discord_id(user_id):
        raise HTTPException(status_code=422, detail="Ungültige Discord-ID.")
    with db() as c:
        c.execute("DELETE FROM admins WHERE user_id=?", (user_id,))
    return {"ok": True}

@app.get("/api/admin/settings")
def get_settings(request: Request):
    require_admin(request)
    with db() as c:
        row = c.execute("SELECT value FROM settings WHERE key='dashboard'").fetchone()
    return {"settings": json.loads(row["value"]) if row else {}, "owner_id": OWNER_ID}

@app.put("/api/admin/settings")
async def put_settings(request: Request):
    require_admin(request)
    data = await request.json()
    settings = data.get("settings", {})
    if not isinstance(settings, dict):
        raise HTTPException(status_code=422, detail="Einstellungen müssen ein Objekt sein.")
    # The Owner ID is fixed in server configuration and cannot be changed from the browser.
    settings.pop("owner_id", None)
    with db() as c:
        c.execute(
            "INSERT INTO settings(key,value) VALUES('dashboard',?) "
            "ON CONFLICT(key) DO UPDATE SET value=excluded.value",
            (json.dumps(settings),),
        )
    return {"ok": True, "owner_id": OWNER_ID}

@app.get("/api/blacklist")
def get_blacklist(request: Request):
    require_admin(request)
    with db() as c:
        rows = c.execute(
            "SELECT user_id, reason, added_by, added_at FROM blacklist ORDER BY added_at DESC"
        ).fetchall()
    return {"entries": [dict(r) for r in rows]}

@app.post("/api/blacklist")
async def add_blacklist(request: Request):
    user = require_admin(request)
    data = await request.json()
    user_id = str(data.get("user_id", "")).strip()
    reason = str(data.get("reason", "")).strip()[:500]
    if not valid_discord_id(user_id):
        raise HTTPException(status_code=422, detail="Bitte eine gültige Discord-Benutzer-ID eingeben.")
    if not reason:
        raise HTTPException(status_code=422, detail="Bitte einen Grund eintragen.")
    with db() as c:
        c.execute(
            "INSERT INTO blacklist(user_id,reason,added_by) VALUES(?,?,?) "
            "ON CONFLICT(user_id) DO UPDATE SET reason=excluded.reason, added_by=excluded.added_by, added_at=CURRENT_TIMESTAMP",
            (user_id, reason, str(user["id"])),
        )
    return {"ok": True, "user_id": user_id}

@app.delete("/api/blacklist/{user_id}")
def remove_blacklist(user_id: str, request: Request):
    require_admin(request)
    if not valid_discord_id(user_id):
        raise HTTPException(status_code=422, detail="Ungültige Discord-ID.")
    with db() as c:
        c.execute("DELETE FROM blacklist WHERE user_id=?", (user_id,))
    return {"ok": True}

@app.get("/")
def dashboard():
    return FileResponse(APP_DIR / "static" / "index.html")

app.mount("/static", StaticFiles(directory=APP_DIR / "static"), name="static")
